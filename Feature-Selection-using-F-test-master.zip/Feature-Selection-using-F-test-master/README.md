# Feature-Selection-using-F-test
Implemented Feature selection algorithm (F-Test) on Genome dataset to select best 100 features out of 4434 features based on their f-scores, and using the new Dataset to train the models and later test the models with the help of testing data
